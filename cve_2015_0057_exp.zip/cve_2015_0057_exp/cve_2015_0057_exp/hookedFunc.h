#ifndef HOOKED_FUNC_HH
#define HOOKED_FUNC_HH

#include <Windows.h>
// ���ù��Ӻ���
extern "C" BOOL hookedFlag ;
extern "C" int hookCount ;

VOID setHookedFunction();
VOID fakedHookFunc(VOID *);
VOID unHook();

#endif // HOOKED_FUNC_HH