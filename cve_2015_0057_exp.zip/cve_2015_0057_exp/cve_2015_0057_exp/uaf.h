#ifndef UAF_H__
#define UAF_H__
#include "hookedFunc.h"
#include "spray.h"
extern "C" HWND hwndVul[hwndCount];
extern "C" HWND hwndVulA;
extern "C" HWND hwndPa;
VOID
triggerVul();
extern "C" BOOL  bDoneExploit ;
#endif // !UAF_H__