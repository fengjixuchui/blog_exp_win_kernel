#ifndef KERNELLEAKS_HH__
#define KERNELLEAKS_HH__
#include <Windows.h>
#include <iostream>

extern "C" typedef void*(NTAPI *lHMValidateHandle)(HWND h, int type);

extern "C" lHMValidateHandle pHmValidateHandle;

typedef struct _HEAD
{
	HANDLE h;
	DWORD  cLockObj;
} HEAD, *PHEAD;

typedef struct _THROBJHEAD
{
	HEAD h;
	PVOID pti;
} THROBJHEAD, *PTHROBJHEAD;
//
typedef struct _THRDESKHEAD
{
	THROBJHEAD h;
	PVOID    rpdesk;
	PVOID       pSelf;   // points to the kernel mode address
} THRDESKHEAD, *PTHRDESKHEAD;
BOOL FindHMValidateHandle();

#endif // !KERNELLEAKS_HH__
